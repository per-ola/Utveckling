package chapter1;

// This application program prints Welcome to Java!
public class Welcome { 
  public static void main(String[] args) { 
    System.out.println("Welcome to Java!");
    System.out.println("Welcome to 1301!");
    System.out.println("Welcome to AASU!");
    System.out.println("Welcome to AASU!");
    System.out.println("Welcome to AASU!");
    System.out.println("Welcome to AASU!");
  }
}
