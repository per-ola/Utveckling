import java.util.Scanner;


public class Lab_3_3c {
	public static void main(String[] args) {
		
		
				int a,b,c;
				double x = 0;
				double y = 0;
						
				Scanner s=new Scanner(System.in);
				System.out.println("Enter the values of a,b, and c");
				a=s.nextInt();
				b=s.nextInt();
				c=s.nextInt();
				int k=(b*b)-4*a*c;
				if(k<0)
				
					System.out.println("No real roots");
				
				else
				{
					double l=Math.sqrt(k);
					x=(-b-l)/2*a;
					y=(-b+l)/2*a;
					System.out.println("Roots of given equation:"+x+" "+y);
				}
	
				double xs0 = StdIn.readDouble();
				double xs1 = StdIn.readDouble();
				double ys0 = StdIn.readDouble();
				double ys1 = StdIn.readDouble();
		
	
				
		StdDraw.setXscale(xs0,xs1);
		StdDraw.setYscale(ys0,ys1);
		//StdDraw.setPenColor(StdDraw.BLUE);
		StdDraw.setPenRadius(10);
		double m = x;
		double n = y;
		
		for ( int i = 0; i < 9; i++);{
		m = 2 * m;
		n = 2 * n;
		StdDraw.point(m,n);
		}
	}
	
}
