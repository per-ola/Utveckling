public class Lab_3_1b {
    public static void main(String[] args) {
    	StdOut.println();
    	StdOut.println("Ange 1-10 tal i intervallet 0.0-0.9:");
    	StdOut.println();
    	StdOut.println("Ctrl-D för att visa resultatet eller avbryta");
    	StdOut.println();
    	double[] a = new double[10];
    	
        // repeat as long as there's more input to read in
        while (!StdIn.isEmpty()) {

            // read in the next integer
            double t = StdIn.readDouble();

            if (t >= 0 && t < 0.1) {
            	a[0] = a[0] + t;
            }
            else if (t >= 0.1 && t < 0.2) {
            	a[1] = a[1] + t;
            }
            else if (t >= 0.2 && t < 0.3) {
            	a[2] = a[2] + t;
            }
        
        	else if (t >= 0.3 && t < 0.4) {
        		a[3] = a[3] + t;
        	}
        
        	else if (t >= 0.4 && t < 0.5) {
        		a[4] = a[4] + t;
        	}
        	
        	else if (t >= 0.5 && t < 0.6) {
        		a[5] = a[5] + t;
            }
            
        	else if (t >= 0.6 && t < 0.7) {
        		a[6] = a[6] + t;
            }
            
        	else if (t >= 0.7 && t < 0.8) {
        		a[7] = a[7] + t;
            }
            
        	else if (t >= 0.8 && t < 0.9) {
        		a[8] = a[8] + t;
            }
            
        	else if (t >= 0.9 && t < 1) {
        		a[9] = a[9] + t;
            }
            
        	else{
        		StdOut.println();	
            	StdOut.println("Talet/talen faller inte inom angivna intervall");
        	}
        }
         
        StdDraw.setXscale(0,25);
		StdDraw.setYscale(0,19);
		StdDraw.filledRectangle((double) 5, (double) 0, (double) 0.5,10 * a[0]);
		StdDraw.filledRectangle((double) 7, (double) 1, (double) 0.5,10 * a[1]);
		StdDraw.filledRectangle((double) 9, (double) 2, (double) 0.5,10 * a[2]);
		StdDraw.filledRectangle((double) 11, (double) 3, (double) 0.5,10 * a[3]);
		StdDraw.filledRectangle((double) 13, (double) 4, (double) 0.5,10 * a[4]);
		StdDraw.filledRectangle((double) 15, (double) 5, (double) 0.5,10 * a[5]);
		StdDraw.filledRectangle((double) 17, (double) 6, (double) 0.5,10 * a[6]);
		StdDraw.filledRectangle((double) 19, (double) 7, (double) 0.5,10 * a[7]);
		StdDraw.filledRectangle((double) 21, (double) 8, (double) 0.5,10 * a[8]);
		StdDraw.filledRectangle((double) 23, (double) 9, (double) 0.5,10 * a[9]);
          
 
    }
}
